.. include:: ../README.rst

Karinov Media Network 
==================
- https://karinov.co.id - jasa digital marketing indonesia
- https://www.navi.id - forum modifikasi otomotif indonesia
- https://blogs.itb.ac.id/feeds - kumpulan tautan berita terbaru indonesia
- https://www.fedora.or.id - portal speaker dan audio
- https://www.autobild.co.id - harian pelita portal informasi terkini
